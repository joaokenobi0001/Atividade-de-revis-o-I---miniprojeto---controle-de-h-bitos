import 'package:flutter/material.dart';
import '../models/habito.dart';

class HabitDetailsScreen extends StatefulWidget {
  final Habito habito;

  const HabitDetailsScreen({super.key, required this.habito});

  @override
  State<HabitDetailsScreen> createState() => _HabitDetailsScreenState();
}

class _HabitDetailsScreenState extends State<HabitDetailsScreen> {
  late TextEditingController _descricaoController;

  @override
  void initState() {
    super.initState();
    _descricaoController = TextEditingController(text: widget.habito.descricao);
  }

  @override
  void dispose() {
    _descricaoController.dispose();
    super.dispose();
  }

  void _salvarDescricao() {
    final novaDescricao = _descricaoController.text.trim();
    if (novaDescricao.isNotEmpty) {
      final habitoAtualizado = Habito(
        nome: widget.habito.nome,
        descricao: novaDescricao,
        concluido: widget.habito.concluido,
      );
      Navigator.pop(context, habitoAtualizado);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Descrição não pode ficar vazia')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.habito.nome),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Descrição:',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _descricaoController,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'Edite a descrição do hábito',
              ),
              maxLines: 3,
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton.icon(
                  onPressed: _salvarDescricao,
                  icon: const Icon(Icons.save),
                  label: const Text('Salvar'),
                ),
                OutlinedButton.icon(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close),
                  label: const Text('Cancelar'),
                ),
              ],
            ),
            const SizedBox(height: 24),
            Text(
              'Status atual: ${widget.habito.concluido ? "Concluído" : "Pendente"}',
              style: const TextStyle(fontStyle: FontStyle.italic),
            ),
          ],
        ),
      ),
    );
  }
}