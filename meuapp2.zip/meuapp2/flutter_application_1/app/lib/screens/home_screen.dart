import 'package:flutter/material.dart';
import '../models/habito.dart';
import 'habit_details_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Habito> _habitos = [];

  @override
  void initState() {
    super.initState();
    _carregarHabitos();
  }

  // Simula carregamento inicial com async/await e Future.delayed
  Future<void> _carregarHabitos() async {
    await Future.delayed(const Duration(seconds: 2));
    setState(() {
      _habitos = [
        Habito(nome: 'Beber água', descricao: 'Beber pelo menos 2 litros de água'),
        Habito(nome: 'Estudar', descricao: 'Estudar Flutter por 1 hora'),
        Habito(nome: 'Exercitar-se', descricao: 'Fazer 30 minutos de exercício físico'),
      ];
    });
  }

  void _toggleConcluido(int index) {
    setState(() {
      _habitos[index].concluido = !_habitos[index].concluido;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Meus Hábitos'),
        centerTitle: true,
        backgroundColor: Colors.green,
      ),
      body: _habitos.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: _habitos.length,
              itemBuilder: (context, index) {
                final habito = _habitos[index];
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: ListTile(
                    leading: Checkbox(
                      value: habito.concluido,
                      onChanged: (_) => _toggleConcluido(index),
                    ),
                    title: Text(
                      habito.nome,
                      style: TextStyle(
                        decoration: habito.concluido
                            ? TextDecoration.lineThrough
                            : null,
                        color: habito.concluido ? Colors.grey : Colors.black,
                      ),
                    ),
                    trailing: const Icon(Icons.arrow_forward),
                    onTap: () async {
                      // Navega para detalhes e recebe possível atualização da descrição
                      final updated = await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => HabitDetailsScreen(habito: habito),
                        ),
                      );
                      if (updated != null && updated is Habito) {
                        setState(() {
                          _habitos[index] = updated;
                        });
                      }
                    },
                  ),
                );
              },
            ),
    );
  }
}