class Habito {
  final String nome;
  final String descricao;
  bool concluido;

  Habito({
    required this.nome,
    required this.descricao,
    this.concluido = false,
  });
}